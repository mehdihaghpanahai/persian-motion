# usage: python3 audio.py <out.wav> <duration_s>   (edit EVENTS below to match scene times)
import sys, numpy as np
from scipy.io import wavfile
SR = 44100
out_path, DUR = sys.argv[1], float(sys.argv[2])
N = int(SR * DUR); out = np.zeros(N); rng = np.random.default_rng(7)
def add(t0, sig, g=1.0):
    i = int(t0 * SR)
    if i >= N: return
    s = sig[:N - i]; out[i:i + len(s)] += s * g
def env(n, a=0.002, d=0.2):
    t = np.arange(n) / SR; return np.minimum(1, t / a) * np.exp(-t / d)
def noise_band(n, lo, hi):
    x = rng.standard_normal(n); X = np.fft.rfft(x); f = np.fft.rfftfreq(n, 1 / SR)
    X[(f < lo) | (f > hi)] = 0; return np.fft.irfft(X, n)
def whoosh(d=0.35):
    n = int(SR * d); t = np.arange(n) / SR; e = np.sin(np.pi * t / d) ** 2
    return noise_band(n, 400, 5000) * e * 0.5
def thunk(d=0.25):
    n = int(SR * d); t = np.arange(n) / SR; f = 110 * np.exp(-t * 14) + 45
    return np.sin(2 * np.pi * np.cumsum(f) / SR) * env(n, .001, .09)
def ding(f=1320, d=0.7):
    n = int(SR * d); t = np.arange(n) / SR
    return (np.sin(2 * np.pi * f * t) + .4 * np.sin(2 * np.pi * 2 * f * t)) * env(n, .002, .25)
def tick():
    n = int(SR * .03); return noise_band(n, 2500, 9000) * env(n, .0005, .008)
def pop(f=900):
    n = int(SR * .09); t = np.arange(n) / SR; return np.sin(2 * np.pi * (f + 400 * np.exp(-t * 60)) * t) * env(n, .001, .03)
# ---------- EDIT: events (seconds) ----------
SCENE_CUTS = [0, 2.6, 3.8, 7.5]; STEP_TITLES = [2.6]; TYPING = []; WORDS = []
for t in SCENE_CUTS: add(t, whoosh(), .5)
for t in STEP_TITLES: add(t + .05, thunk(), .6); add(t + .1, ding(), .3)
for a, b in TYPING:
    for t in np.arange(a, b, .12): add(t, tick(), .2)
for t in WORDS: add(t, pop(), .25)
tt = np.arange(N) / SR
out += sum(np.sin(2 * np.pi * f * tt) for f in [196, 247, 294]) * .02 * np.minimum(1, tt / 1.5) * np.minimum(1, (DUR - tt) / 1.5)
out = np.tanh(out * 1.2); out /= (np.abs(out).max() + 1e-9); out *= .85
wavfile.write(out_path, SR, (out * 32767).astype(np.int16)); print('wrote', out_path)
