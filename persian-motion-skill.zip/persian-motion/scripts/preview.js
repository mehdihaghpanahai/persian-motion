// usage: node preview.js <html> "1.0,3.5,8" [outdir=.]  -> still_<t>.png + overflow report
const { chromium } = require('playwright');
const path = require('path');
(async () => {
  const [html, times, outdir = '.'] = process.argv.slice(2);
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1080, height: 1920 } });
  page.on('pageerror', e => console.log('PAGE ERROR', e.message));
  await page.goto('file://' + path.resolve(html));
  await page.evaluate(() => document.fonts.ready);
  for (const t of times.split(',').map(Number)) {
    await page.evaluate(t => seek(t), t);
    const bad = await page.evaluate(() => [...document.querySelectorAll('.ln')].filter(e => e.offsetParent).map(e => {
      const kids = [...e.children]; if (!kids.length) return null;
      const xs = kids.map(k => k.getBoundingClientRect()); const l = Math.min(...xs.map(r => r.left)), r = Math.max(...xs.map(r => r.right));
      return (l < 20 || r > 1060) ? `overflow: "${e.textContent.slice(0, 30)}" x=${Math.round(l)}..${Math.round(r)}` : null;
    }).filter(Boolean));
    await page.screenshot({ path: path.join(outdir, `still_${t}.png`) });
    console.log(t, bad.length ? bad.join(' | ') : 'ok');
  }
  await browser.close();
})();
