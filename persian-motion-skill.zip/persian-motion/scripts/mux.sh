#!/bin/bash
# usage: bash mux.sh silent.mp4 audio.wav final.mp4
ffmpeg -v error -y -i "$1" -i "$2" -c:v copy -c:a aac -b:a 192k -shortest "$3" && echo "wrote $3"
