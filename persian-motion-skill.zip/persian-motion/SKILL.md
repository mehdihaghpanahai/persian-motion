---
name: persian-motion
description: Build short Persian (Farsi, RTL) text-motion videos (Instagram Reels / Shorts, 1080x1920) from an idea. Use when the user asks for a Persian/Farsi motion graphic, kinetic text, animated explainer or reel, or any animation with Persian text. Handles RTL, Persian digits, mixed Latin words, word-by-word reveals and MP4 export.
---

# Persian Motion

Turns an idea into a 10–30 s vertical Persian text-motion video: scene by scene, word-by-word reveals, step titles instead of subtitles, optional synthesized sound, exported as MP4.

## Workflow

1. **Clarify only what's missing.** Topic, length (default 20 s), tone (default colloquial, friendly), handle/brand text for the footer (optional). Don't ask more than one question.
2. **Write the script as scenes** before any code (see "Script rules"). Persian text must be colloquial and natural, never a literal translation.
3. **Copy `assets/template.html`** into the working folder and fill the `SC` array (scenes → lines → words). Read `references/rtl-rules.md` first; it lists the mistakes that always happen with Persian text.
4. **Preview before rendering.** Run `node scripts/preview.js <html> "t1,t2,..."` to take stills at key times, look at them, fix overlaps/overflow.
5. **Render:** `node scripts/render.js <html> <silent.mp4> <seconds> [fps]`.
6. **Sound (optional):** edit the event list in `scripts/audio.py`, run it, then `bash scripts/mux.sh silent.mp4 audio.wav final.mp4`.
7. **Deliver** the mp4 with a 2-line summary. Offer caption + cover as the next step; don't build them unasked.

## Script rules

- Hook in the first 3 s; one idea per scene; 1–4 lines per scene; at most 4–5 words per line.
- Steps are shown with **big step-title scenes** («قدم ۱», «قدم ۲» …) and a small tag on top of each following scene, not with subtitles. No subtitles unless the user asks.
- Highlight one key word per scene (orange color or wipe highlight), not more.
- End with a CTA scene (save / comment keyword / follow). The keyword must be a single easy Persian word.
- Timing: ~0.12 s stagger per word, a scene holds 1.2–4 s, scene cut with a small punch scale (1.035 → 1). Total words ≈ 2.5 words/second max.

## Visual style (default "cream-coral")

See `references/style-text-motion.md`. Palette: cream `#faf6ee`, charcoal `#25272d`, coral `#ff5a3c`, muted gray `#8a8578`. Bold look is made with `-webkit-text-stroke` (Persian fonts often lack a real bold). Props (pills, cards, buttons) stay minimal and sit beside the titles; no characters unless the user asks.

## Fonts

Use a freely redistributable Persian font such as **Vazirmatn** (OFL) or another font the user owns; don't ship fonts you can't redistribute. The template declares a font stack; if a font file is available locally, add an `@font-face` pointing to it. Persian digits come from the `FD()` helper.

## Rendering notes

- Animation is **deterministic**: all state is computed in `seek(t)`; the renderer calls it frame by frame (Playwright) and pipes JPEGs to ffmpeg. No CSS animations/timers.
- Needs: Node + `playwright` (chromium), ffmpeg, and Python with numpy/scipy for sound.
- The same HTML structure (scenes + `seek(t)`) can be ported to other HTML-video frameworks (e.g. HyperFrames/GSAP timelines); the rules in `references/` apply unchanged. This skill's scripts were tested only with its own renderer.

## Quality checklist (run before delivering)

- No line overflows the 1080 px width (preview stills at the end of each scene).
- Latin words/brand names are in correct order (use `l` style tokens, see rules).
- Percent signs and numbers read correctly («۹۰ درصد»).
- Nothing overlaps props; handle at the bottom is readable.
- Total duration matches the request; the last scene holds ≥ 1.2 s.
