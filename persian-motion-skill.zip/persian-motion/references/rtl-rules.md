# Persian / RTL rules for HTML motion

These are the failures that happen every time; check each one.

1. **Direction.** Every Persian text container needs `direction:rtl; text-align:center`. Words are separate inline-blocks; with `direction:rtl` the first word in the array appears on the right.
2. **Latin words inside Persian lines.** Each Latin phrase must be ONE token in the word array (`'Claude Code'`, not `'Claude','Code'`), styled `direction:ltr` and Latin font (Inter). Two Latin tokens side by side in an RTL line are displayed in reversed order.
3. **Percent sign.** `۹۰٪` / `90%` renders on the wrong side. Write «۹۰ درصد».
4. **Digits.** Convert with `FD()` (0-9 → ۰-۹). Keep Latin digits only inside Latin tokens (URLs, code).
5. **Punctuation.** Use «» for quotes, `؟` and `،`. Put `!` and `؟` inside the same token as the word they follow so they don't jump to the other side.
6. **Half-spaces (ZWNJ).** Write «می‌شه», «ساخته‌شده», «ایده‌ی» with U+200C. Don't split such a word into two tokens.
7. **Bold.** Most Persian fonts ship regular only → fake bold with `-webkit-text-stroke:1.4px currentColor` (titles 2px). Don't use `font-weight` for Persian.
8. **Letter-spacing must be 0** for Persian; any spacing breaks the joined letters.
9. **Per-word animation** must not split inside a word (letters would disconnect). Animate whole words only; never per letter.
10. **Blur-in** (`filter:blur`) on word spans is fine; avoid `overflow:hidden` per word, it clips descenders/dots.
11. **Line length.** At 1080 px: size 120 px ≈ 4 short words, 96 px ≈ 5, 68 px ≈ 7. Use `white-space:nowrap` and verify with a still.
12. **Typing effect** for Persian: reveal by character with `slice()`; the cursor `|` sits at the left end of the visible text in RTL, which is acceptable; or skip the cursor.
13. **Mixed numbers/steps**: step numbers as large Persian digits («۱»), with three progress bars (left-to-right is acceptable for bars).
14. **Footer handle** is Latin, `direction:ltr`, small, muted.
