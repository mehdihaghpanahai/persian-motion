# Style: cream-coral text motion

- Canvas 1080×1920, 30 fps, background `#faf6ee`. Footer handle at y=1862, 30 px, letter-spacing 2px, `#a9a496`.
- Titles: 96–150 px, charcoal; key word in coral `#ff5a3c` or with a coral wipe highlight (word turns white on the wipe).
- Secondary line: 52–68 px, `#8a8578`.
- **Step scenes:** big italic «قدم» (150 px) + huge coral digit (520 px) + 3 bars (the current and previous ones coral). 1.0–1.2 s. Every content scene after it carries a small tag (54 px, gray) at the top: «قدم ۱».
- **Word reveal:** opacity 0→1 over 0.15 s, blur 14→0 px, translateY 40→0 with overshoot (ease-out-back), stagger 0.12 s.
- **Scene cut:** hard cut + scale 1.035→1 in 0.2 s, slow push-in (+2 %) over the scene.
- **Props** (optional, minimal): white pill with soft shadow (URL bar, chips), white card (prompt box), selection outline coral 8 px, black toast («✓ کپی شد»), coral round buttons. Props fade/slide in after the title words.
- **CTA scene:** bookmark icon (fills coral), comment box with the keyword typed in, last line says what the viewer will receive.
- **Sound:** soft swoosh at every scene cut, thunk+ding at step titles, ticks while typing, pop on words; keep master at ~-6 dB.
