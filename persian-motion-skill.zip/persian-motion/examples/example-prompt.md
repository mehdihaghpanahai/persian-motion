# Example requests
- «یه ریل ۲۰ ثانیه‌ای تکست‌موشن درباره‌ی ۳ اشتباه رایج توی پرامپت‌نویسی بساز. بدون زیرنویس، مراحل با تایتل.»
- «موشن ۱۵ ثانیه‌ای: چطور با Claude پوستر طراحی کنم؟ CTA: کامنت کن «پوستر».»

# Expected scene plan (for the first request)
0–2.6 hook «۳ اشتباه / توی پرامپت‌نویسی» · 2.6–3.8 step 1 · 3.8–7 «اشتباه ۱: مبهم نوشتن» + example · … · last 4 s CTA (save + comment keyword).
